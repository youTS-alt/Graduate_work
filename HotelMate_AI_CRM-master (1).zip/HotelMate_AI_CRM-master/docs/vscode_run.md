# Запуск проекта в VS Code

Инструкция рассчитана на Windows и запуск проекта из `VS Code`.

## Что нужно установить заранее

1. `Git` для клонирования проекта.
2. `Python 3.11+`.
3. `VS Code`.
4. Расширения `Python` и `Pylance` в `VS Code`.
5. `Ollama`, потому что AI-чат проекта ходит в локальный API `http://localhost:11434/api/chat`.

## 1. Открыть проект в VS Code

1. Запустите `VS Code`.
2. Выберите `File -> Open Folder`.
3. Откройте папку проекта `HotelMate_AI_CRM`.
4. Откройте встроенный терминал: `Terminal -> New Terminal`.

## 2. Создать и активировать виртуальное окружение

В терминале `PowerShell` выполните:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Если PowerShell запрещает запуск скриптов, временно разрешите их для текущего пользователя:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Потом снова выполните:

```powershell
.venv\Scripts\Activate.ps1
```

## 3. Установить зависимости проекта

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

В проекте для AI-чата используется пакет `httpx`, поэтому он добавлен в `requirements.txt` и установится вместе с Django.

## 4. Установить Ollama

1. Перейдите на сайт `https://ollama.com/download`.
2. Скачайте версию для Windows.
3. Установите Ollama обычным установщиком.
4. После установки откройте новое окно терминала и проверьте команду:

```powershell
ollama --version
```

## 5. Скачать модель для Ollama

Проект сейчас ожидает модель:

```text
llama3.1:8b
```

Скачайте её командой:

```powershell
ollama pull llama3.1:8b
```

Если на компьютере мало RAM или VRAM, можно использовать более лёгкую модель, но тогда нужно поменять значение `OLLAMA_MODEL` в файле [ui/agent.py](C:/Users/Ary/PycharmProjects/HotelMate_AI_CRM/ui/agent.py).

## 6. Запустить Ollama

Обычно на Windows Ollama стартует как приложение и поднимает локальный сервер автоматически. Проверить можно так:

```powershell
ollama list
```

Если нужно вручную проверить API:

```powershell
Invoke-RestMethod -Method Get -Uri http://localhost:11434/api/tags
```

Если команда вернула список моделей, значит Ollama доступна.

## 7. Подготовить базу данных

В репозитории уже есть файл `db.sqlite3`, поэтому для быстрого старта можно просто запускать проект.

Если хотите развернуть базу заново:

```powershell
python manage.py migrate
python manage.py seed_data
```

Если нужно пересоздать демо-данные с очисткой:

```powershell
python manage.py seed_data --reset
```

## 8. Запустить Django-сервер

```powershell
python manage.py runserver
```

После запуска откройте в браузере:

```text
http://127.0.0.1:8000/
```

Основные страницы:

- Главная: `http://127.0.0.1:8000/`
- AI-консоль: `http://127.0.0.1:8000/ai/`
- Обращения: `http://127.0.0.1:8000/tickets/`
- Бронирования: `http://127.0.0.1:8000/bookings/`

## 9. Запуск через кнопку в VS Code

В проект уже добавлена конфигурация запуска. Дальше:

1. Откройте вкладку `Run and Debug`.
2. Выберите конфигурацию `Django: runserver`.
3. Нажмите `F5`.

Перед этим убедитесь, что внизу в `VS Code` выбран интерпретатор из `.venv`.

## 10. Если AI-чат не отвечает

Проверьте по порядку:

1. Активировано ли виртуальное окружение `.venv`.
2. Установились ли зависимости через `pip install -r requirements.txt`.
3. Запущена ли `Ollama`.
4. Скачана ли модель `llama3.1:8b`.
5. Доступен ли адрес `http://localhost:11434`.

В проекте запрос к Ollama зашит в [ui/agent.py](C:/Users/Ary/PycharmProjects/HotelMate_AI_CRM/ui/agent.py):

- `OLLAMA_URL = "http://localhost:11434/api/chat"`
- `OLLAMA_MODEL = "llama3.1:8b"`

## Быстрый сценарий запуска

Если всё уже установлено, достаточно выполнить:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
ollama pull llama3.1:8b
python manage.py runserver
```
